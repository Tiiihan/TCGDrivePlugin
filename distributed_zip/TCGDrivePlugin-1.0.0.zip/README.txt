﻿TCGDrivePlugin 1.0.0
=======================

Google Drive integration plugin for Total Commander.

INSTALLATION
------------
Easiest:
  Open this ZIP inside Total Commander itself (just enter the .zip in a
  TC panel as you would a folder). TC detects pluginst.inf and offers a
  one-click install вЂ” accept the prompt and the plugin lands in
  <TC>\plugins\wfx\TCGDrivePlugin\ and is registered automatically.

Alternative (manual):
  Extract the ZIP into <TC>\plugins\wfx\TCGDrivePlugin\, then register it in
  Total Commander: Configuration > Options > Plugins > File system plugins
  (WFX) > Configure / Add.

REQUIREMENTS
------------
* Windows 10 or 11 (64-bit)
* Total Commander x64 (version 9.0 or newer)
* Microsoft Edge WebView2 Runtime
    Pre-installed on Windows 11 and on most up-to-date Windows 10 systems.
    If missing: install "Microsoft Edge WebView2 Evergreen Bootstrapper"
    from Microsoft.
* Microsoft Visual C++ 2015-2022 x64 Redistributable
    Install vc_redist.x64.exe from Microsoft if the plugin fails to load.

FIRST USE
---------
Open Network Neighborhood -> Google Drive in Total Commander.
Click [Sign in to Google Drive]. A secure Google sign-in window opens
inside the plugin (no external browser). After you complete the sign-in,
the panel refreshes to your Drive files.

DIAGNOSTICS
-----------
Log file: %APPDATA%\TCGDrivePlugin\plugin.log
Config:   %APPDATA%\TCGDrivePlugin\config.ini
Tokens:   %APPDATA%\TCGDrivePlugin\tokens.dat (DPAPI-encrypted, per user)
